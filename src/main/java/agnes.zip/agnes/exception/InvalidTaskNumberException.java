package agnes.exception;

public class InvalidTaskNumberException extends Exception {
    public InvalidTaskNumberException(String message) {
        super(message);
    }
}
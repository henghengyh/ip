package agnes.exception;

public class TaskIndexOutOfBoundsException extends Exception {
    public TaskIndexOutOfBoundsException(String message) {
        super(message);
    }
}
package agnes;

import agnes.task.TaskList;
import agnes.ui.Ui;
import agnes.parser.Parser;
import agnes.exception.*;
import agnes.storage.Storage;

public class Agnes {
    private final TaskList tasks = new TaskList();
    private final Storage storage = new Storage("./data/tasks.txt");
    private final Ui ui = new Ui();
    private final Parser parser = new Parser();

    public static void main(String[] args) {
        Agnes myBot = new Agnes();
        myBot.run();
    }

    private void run() {
        ui.startConversation();
        ui.userInput();
        ui.endConversation();
    }
}
